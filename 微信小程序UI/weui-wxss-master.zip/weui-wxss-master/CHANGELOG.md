#### v 1.1.1 (2017-01-18)

- 【同步weui】 增加扩展类.weui-loading_transparent
- 【同步weui】 更新普通警告图标颜色
- 【修复】 fix navbar的activeIndex #20

#### v 1.1.0 (2016-12-06)

- 【优化】 跟随weui的版本号
- 【优化】 loading的base64
- 【增强】 增加组件 badge 徽章

#### v0.1.1 (2016-11-10)

- 【修复】 navbar的样式按小程序的规范来重新编写

#### v0.1.0 (2016-11-10)

初始发布

- Initial release